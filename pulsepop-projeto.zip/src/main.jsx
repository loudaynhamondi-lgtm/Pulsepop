import React from 'react'
import ReactDOM from 'react-dom/client'
import PulsePop from './PulsePop.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PulsePop />
  </React.StrictMode>,
)
