import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://yihgtjkzksjewxzuyrxs.supabase.co'
const supabaseKey = 'sb_publishable_n5ZDYRt5so1zQIdi5zveug_UTQcAiWa'

export const supabase = createClient(supabaseUrl, supabaseKey)
