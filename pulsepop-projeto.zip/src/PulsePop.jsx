import { useState, useEffect, useRef } from "react";
import { Zap, Search, Clock, MapPin, ShoppingBag, User, X, QrCode, CheckCircle2, Plus, Flame, LogOut } from "lucide-react";
import { supabase } from "./supabaseClient";

// ---- Helpers ----
const uid = () => Math.random().toString(36).slice(2, 10);

const SEED_BATCHES = [
  { id: uid(), name: "Pão de Fermentação Natural", vendor: "Padaria Dona Maria", dist: "300m", price: 18, qty: 3, emoji: "🍞", createdAt: Date.now(), ttlMin: 14 },
  { id: uid(), name: "Cupcakes de Castanha", vendor: "Confeitaria Sweet Home", dist: "650m", price: 12, qty: 2, emoji: "🧁", createdAt: Date.now(), ttlMin: 8 },
  { id: uid(), name: "Caldo Verde Caseiro (500ml)", vendor: "Cozinha da Vovó", dist: "1.1km", price: 22, qty: 5, emoji: "🍲", createdAt: Date.now(), ttlMin: 25 },
];

function minutesLeft(batch) {
  const elapsed = (Date.now() - batch.createdAt) / 60000;
  return Math.max(0, Math.ceil(batch.ttlMin - elapsed));
}

function LoginScreen({ onLogin }) {
  const [isSignup, setIsSignup] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!email.trim()) {
      setError("Informe um e-mail.");
      return;
    }
    if (isSignup && !name.trim()) {
      setError("Informe seu nome.");
      return;
    }
    try {
      const key = `pulsepop:user:${email.trim().toLowerCase()}`;
      const existing = await window.storage.get(key, true).catch(() => null);
      if (isSignup) {
        const profile = { name: name.trim(), email: email.trim().toLowerCase() };
        await window.storage.set(key, JSON.stringify(profile), true);
        onLogin(profile);
      } else {
        if (!existing?.value) {
          setError("Não encontramos essa conta. Tente cadastrar.");
          return;
        }
        onLogin(JSON.parse(existing.value));
      }
    } catch {
      setError("Erro ao acessar. Tente novamente.");
    }
  }

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 bg-gradient-to-b from-cyan-700 to-slate-900 text-white h-full">
      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center mb-4">
        <Zap size={26} className="text-cyan-600" fill="currentColor" />
      </div>
      <h1 className="text-xl font-bold mb-1">PulsePop</h1>
      <p className="text-[12px] text-cyan-100 mb-6 text-center">Comércio hiper-local, em tempo real</p>

      <form onSubmit={handleSubmit} className="w-full space-y-2.5">
        {isSignup && (
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Seu nome"
            className="w-full text-[13px] bg-white/95 rounded-xl px-3.5 py-2.5 outline-none text-slate-800"
          />
        )}
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="E-mail"
          type="email"
          className="w-full text-[13px] bg-white/95 rounded-xl px-3.5 py-2.5 outline-none text-slate-800"
        />
        {error && <p className="text-rose-200 text-[11px]">{error}</p>}
        <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 font-bold py-2.5 rounded-xl text-[13px] shadow transition">
          {isSignup ? "Criar conta" : "Entrar"}
        </button>
      </form>

      <button onClick={() => { setIsSignup(!isSignup); setError(""); }} className="text-[12px] text-cyan-100 mt-4 underline">
        {isSignup ? "Já tenho conta — entrar" : "Não tenho conta — cadastrar"}
      </button>
      <p className="text-[10px] text-cyan-200/70 mt-8 text-center px-4">
        Autenticação simplificada para demonstração. Numa versão de produção, use um provedor real (ex: Supabase Auth) com senha e verificação de e-mail.
      </p>
    </div>
  );
}

export default function PulsePop() {
  const [user, setUser] = useState(null);
  const [checkingSession, setCheckingSession] = useState(true);
  const [mode, setMode] = useState("consumer"); // consumer | producer
  const [tab, setTab] = useState("feed"); // feed | orders | profile
  const [batches, setBatches] = useState(SEED_BATCHES);
  const [orders, setOrders] = useState([]);
  const [checkoutItem, setCheckoutItem] = useState(null);
  const [toast, setToast] = useState(null);
  const [search, setSearch] = useState("");
  const [loaded, setLoaded] = useState(false);
  const toastTimer = useRef(null);

  // Restore session
  useEffect(() => {
    (async () => {
      try {
        const session = await window.storage.get("pulsepop:session", false);
        if (session?.value) setUser(JSON.parse(session.value));
      } catch {}
      setCheckingSession(false);
    })();
  }, []);

  function handleLogin(profile) {
    setUser(profile);
    window.storage.set("pulsepop:session", JSON.stringify(profile), false).catch(() => {});
  }

  function handleLogout() {
    setUser(null);
    window.storage.delete("pulsepop:session", false).catch(() => {});
  }

  // Load persisted data from Supabase (shared batches, personal orders) — only once logged in
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: batchRows, error: batchErr } = await supabase
        .from("batches")
        .select("*")
        .order("created_at", { ascending: false });
      if (!batchErr && batchRows) {
        setBatches(
          batchRows.map((b) => ({
            id: b.id,
            name: b.name,
            vendor: b.vendor,
            dist: b.vendor === "Seu Estabelecimento" ? "0m" : "—",
            price: Number(b.price),
            qty: b.qty,
            emoji: b.emoji || "🥐",
            createdAt: new Date(b.created_at).getTime(),
            ttlMin: b.ttl_minutes,
          }))
        );
      } else if (batchErr) {
        showToast("Sem conexão com o banco — usando dados de exemplo.");
      }

      const { data: orderRows, error: orderErr } = await supabase
        .from("orders")
        .select("*")
        .eq("user_email", user.email)
        .order("created_at", { ascending: false });
      if (!orderErr && orderRows) {
        setOrders(
          orderRows.map((o) => ({
            id: o.id,
            name: o.name,
            price: Number(o.price),
            vendor: o.vendor,
            at: new Date(o.created_at).getTime(),
          }))
        );
      }
      setLoaded(true);
    })();
  }, [user]);

  // Note: with Supabase, writes happen directly in handleCreateBatch and confirmOrder below —
  // no need for a generic "save on every change" effect like the local-storage version had.

  // Expire batches with 0 minutes left
  useEffect(() => {
    const t = setInterval(() => {
      setBatches((prev) => prev.filter((b) => minutesLeft(b) > 0));
    }, 30000);
    return () => clearInterval(t);
  }, []);

  function showToast(msg) {
    clearTimeout(toastTimer.current);
    setToast(msg);
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }

  async function handleCreateBatch(e) {
    e.preventDefault();
    const form = e.target;
    const name = form.name.value.trim();
    const qty = parseInt(form.qty.value, 10);
    const price = parseFloat(form.price.value);
    const ttlMin = parseInt(form.ttl.value, 10);
    if (!name || !qty || !price) return;
    const emojiPool = ["🥐", "🍰", "🥗", "🍕", "🥧", "🍱", "🧇"];
    const emoji = emojiPool[Math.floor(Math.random() * emojiPool.length)];

    const { data, error } = await supabase
      .from("batches")
      .insert({
        name,
        vendor: "Seu Estabelecimento",
        price,
        qty,
        emoji,
        ttl_minutes: ttlMin,
      })
      .select()
      .single();

    if (error) {
      showToast("Não foi possível salvar o lote. Tente novamente.");
      return;
    }

    setBatches((prev) => [
      {
        id: data.id,
        name: data.name,
        vendor: data.vendor,
        dist: "0m",
        price: Number(data.price),
        qty: data.qty,
        emoji: data.emoji,
        createdAt: new Date(data.created_at).getTime(),
        ttlMin: data.ttl_minutes,
      },
      ...prev,
    ]);
    form.reset();
    showToast("Lote disparado no radar dos vizinhos!");
    setMode("consumer");
  }

  const [pixData, setPixData] = useState(null);
  const [pixLoading, setPixLoading] = useState(false);

  async function openCheckout(batch) {
    if (minutesLeft(batch) <= 0 || batch.qty <= 0) return;
    setCheckoutItem(batch);
    setPixData(null);
    setPixLoading(true);
    try {
      const resp = await fetch(
        "https://yihgtjkzksjewxzuyrxs.supabase.co/functions/v1/create-pix-payment",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amount: batch.price,
            description: batch.name,
            payerEmail: user.email,
          }),
        }
      );
      const data = await resp.json();
      if (data.qr_code_image || data.qr_code) {
        setPixData(data);
      } else {
        setPixData({ error: true });
      }
    } catch {
      setPixData({ error: true });
    } finally {
      setPixLoading(false);
    }
  }

  async function confirmOrder() {
    if (!checkoutItem) return;
    const item = checkoutItem;
    const newQty = Math.max(0, item.qty - 1);

    const { error: updateErr } = await supabase
      .from("batches")
      .update({ qty: newQty })
      .eq("id", item.id);

    const { data: orderData, error: orderErr } = await supabase
      .from("orders")
      .insert({
        user_email: user.email,
        batch_id: item.id,
        name: item.name,
        price: item.price,
        vendor: item.vendor,
        paid: true, // marcado como pago aqui; num fluxo real com Mercado Pago,
                    // isso só vira "true" quando o webhook confirmar o PIX
      })
      .select()
      .single();

    if (updateErr || orderErr) {
      showToast("Não foi possível concluir a reserva. Tente novamente.");
      return;
    }

    setBatches((prev) => prev.map((b) => (b.id === item.id ? { ...b, qty: newQty } : b)));
    setOrders((prev) => [
      { id: orderData.id, name: item.name, price: item.price, vendor: item.vendor, at: Date.now() },
      ...prev,
    ]);
    setCheckoutItem(null);
    showToast("Pagamento PIX aprovado! Reserva confirmada.");
  }

  const filtered = batches.filter((b) =>
    b.name.toLowerCase().includes(search.toLowerCase())
  );

  if (checkingSession) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 font-sans">
        <div className="w-full max-w-[380px] h-[780px] bg-slate-50 rounded-[2.5rem] shadow-2xl border-[8px] border-slate-800 flex items-center justify-center">
          <Zap size={28} className="text-cyan-600 animate-pulse" />
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 font-sans">
        <div className="w-full max-w-[380px] h-[780px] bg-slate-50 rounded-[2.5rem] shadow-2xl border-[8px] border-slate-800 overflow-hidden flex flex-col relative">
          <div className="bg-slate-900 text-white px-5 py-1.5 flex justify-between items-center text-[11px] font-medium">
            <span>9:41</span>
            <span className="tracking-wide">PulsePop</span>
          </div>
          <LoginScreen onLogin={handleLogin} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-[380px] h-[780px] bg-slate-50 rounded-[2.5rem] shadow-2xl border-[8px] border-slate-800 overflow-hidden flex flex-col relative">
        {/* Status bar */}
        <div className="bg-slate-900 text-white px-5 py-1.5 flex justify-between items-center text-[11px] font-medium">
          <span>9:41</span>
          <span className="tracking-wide">PulsePop</span>
        </div>

        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-700 to-cyan-600 text-white px-5 py-3.5 flex flex-col gap-2.5 shadow-md z-10">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <Zap size={16} className="text-cyan-600" fill="currentColor" />
              </div>
              <div>
                <h1 className="font-bold text-[15px] leading-tight">PulsePop</h1>
                <p className="text-[10px] text-cyan-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Raio ativo: 2.5km
                </p>
              </div>
            </div>
            <div className="flex bg-cyan-800/60 p-1 rounded-lg text-[11px] font-semibold">
              <button
                onClick={() => setMode("consumer")}
                className={`px-3 py-1 rounded-md transition ${mode === "consumer" ? "bg-white text-cyan-700" : "text-cyan-100"}`}
              >
                Comprar
              </button>
              <button
                onClick={() => setMode("producer")}
                className={`px-3 py-1 rounded-md transition ${mode === "producer" ? "bg-white text-cyan-700" : "text-cyan-100"}`}
              >
                Vender
              </button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-3.5 pb-20 bg-slate-100">
          {mode === "consumer" ? (
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 flex items-center gap-2 shadow-sm">
                  <Search size={14} className="text-slate-400" />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Buscar lote (pão, bolo...)"
                    className="w-full text-[13px] outline-none bg-transparent text-slate-700"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center pt-1">
                <h2 className="font-bold text-slate-800 text-[14px] flex items-center gap-1.5">
                  <Flame size={15} className="text-amber-500" /> Lotes saindo agora
                </h2>
                <span className="text-[10px] font-semibold text-cyan-700 bg-cyan-100 px-2 py-0.5 rounded-full">
                  {filtered.length} ativos
                </span>
              </div>

              {filtered.length === 0 && (
                <div className="text-center text-slate-400 text-[12px] py-10">
                  Nenhum lote por perto agora. Volte em instantes.
                </div>
              )}

              <div className="space-y-2.5">
                {filtered.map((b) => {
                  const mins = minutesLeft(b);
                  const soldOut = b.qty <= 0 || mins <= 0;
                  const urgent = mins <= 10;
                  return (
                    <div
                      key={b.id}
                      className={`bg-white rounded-2xl p-3.5 shadow-sm border relative overflow-hidden ${soldOut ? "opacity-50 border-slate-200" : "border-slate-200 hover:border-cyan-400"}`}
                    >
                      <div className={`absolute top-0 right-0 text-white text-[9px] font-bold px-2.5 py-1 rounded-bl-xl uppercase ${soldOut ? "bg-slate-400" : urgent ? "bg-rose-500" : "bg-amber-500"}`}>
                        {soldOut ? "Esgotado" : `Restam ${b.qty}`}
                      </div>
                      <div className="flex gap-3">
                        <div className="w-16 h-16 bg-slate-100 rounded-xl flex items-center justify-center flex-shrink-0 text-2xl">
                          {b.emoji}
                        </div>
                        <div className="flex-1 pr-5">
                          <h3 className="font-bold text-slate-800 text-[13px] leading-tight">{b.name}</h3>
                          <p className="text-[11px] text-slate-500 mb-1.5">
                            {b.vendor} • <span className="text-emerald-600 font-semibold">{b.dist}</span>
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-cyan-700 font-bold text-[14px]">
                              R$ {b.price.toFixed(2)}
                            </span>
                            <button
                              onClick={() => openCheckout(b)}
                              disabled={soldOut}
                              className="bg-cyan-600 hover:bg-cyan-700 disabled:bg-slate-300 text-white text-[11px] font-semibold px-3 py-1.5 rounded-lg shadow transition"
                            >
                              Reservar
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Clock size={11} className={urgent ? "text-rose-500" : "text-amber-500"} />
                          {soldOut ? "Encerrado" : `Expira em ${mins} min`}
                        </span>
                        <span>Retirada no balcão</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="space-y-3.5">
              <div className="bg-gradient-to-r from-cyan-700 to-cyan-600 rounded-2xl p-3.5 text-white shadow-sm">
                <h2 className="font-bold text-[15px] mb-0.5">Painel do produtor</h2>
                <p className="text-[11px] text-cyan-100">
                  Dispare lotes para vizinhos num raio de até 3km em segundos.
                </p>
              </div>

              <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-800 text-[13px] mb-2.5 flex items-center gap-1.5">
                  <Plus size={14} className="text-cyan-600" /> Cadastrar novo lote
                </h3>
                <form onSubmit={handleCreateBatch} className="space-y-2.5">
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">Nome do produto</label>
                    <input name="name" required placeholder="Ex: Bolo de chocolate" className="w-full text-[12px] bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 outline-none focus:border-cyan-500" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-600 mb-1">Quantidade</label>
                      <input name="qty" type="number" min="1" required placeholder="5" className="w-full text-[12px] bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 outline-none focus:border-cyan-500" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-600 mb-1">Preço (R$)</label>
                      <input name="price" type="number" step="0.01" min="0.01" required placeholder="25.00" className="w-full text-[12px] bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 outline-none focus:border-cyan-500" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">Validade do lote</label>
                    <select name="ttl" className="w-full text-[12px] bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 outline-none focus:border-cyan-500">
                      <option value="15">15 minutos (urgente)</option>
                      <option value="30">30 minutos</option>
                      <option value="60">1 hora</option>
                    </select>
                  </div>
                  <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 rounded-lg text-[13px] shadow transition flex items-center justify-center gap-1.5">
                    <Zap size={14} /> Disparar no radar
                  </button>
                </form>
              </div>

              <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-800 text-[13px] mb-2.5">Seus lotes ativos</h3>
                <div className="space-y-2">
                  {batches.filter((b) => b.vendor === "Seu Estabelecimento" && minutesLeft(b) > 0).length === 0 && (
                    <p className="text-[11px] text-slate-400">Nenhum lote seu no ar agora.</p>
                  )}
                  {batches
                    .filter((b) => b.vendor === "Seu Estabelecimento" && minutesLeft(b) > 0)
                    .map((b) => (
                      <div key={b.id} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-[11px]">
                        <div>
                          <p className="font-bold text-slate-800">{b.name} ({b.qty} un.)</p>
                          <p className="text-slate-400">Expira em {minutesLeft(b)} min</p>
                        </div>
                        <span className="bg-emerald-100 text-emerald-700 font-bold px-2 py-1 rounded-md">Ativo</span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {tab === "profile" && (
            <div className="absolute inset-0 bg-slate-100 p-3.5 pb-20 overflow-y-auto">
              <div className="bg-white rounded-2xl p-4 border border-slate-200 flex items-center gap-3 mb-3">
                <div className="w-11 h-11 bg-cyan-600 rounded-full flex items-center justify-center text-white font-bold">
                  {user.name?.[0]?.toUpperCase() || "?"}
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-[13px]">{user.name}</p>
                  <p className="text-[11px] text-slate-400">{user.email}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 bg-white border border-rose-200 text-rose-600 font-semibold py-2.5 rounded-xl text-[12px] shadow-sm"
              >
                <LogOut size={14} /> Sair da conta
              </button>
            </div>
          )}

          {tab === "orders" && (
            <div className="absolute inset-0 bg-slate-100 p-3.5 pb-20 overflow-y-auto">
              <h2 className="font-bold text-slate-800 text-[14px] mb-3">Seus pedidos</h2>
              {orders.length === 0 ? (
                <p className="text-[12px] text-slate-400 text-center py-10">Você ainda não fez nenhuma reserva.</p>
              ) : (
                <div className="space-y-2">
                  {orders.map((o) => (
                    <div key={o.id} className="bg-white rounded-xl p-3 border border-slate-200 flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-slate-800 text-[12px]">{o.name}</p>
                        <p className="text-[10px] text-slate-400">{o.vendor}</p>
                      </div>
                      <span className="font-bold text-cyan-700 text-[13px]">R$ {o.price.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>

        {/* Bottom nav */}
        <nav className="absolute bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-6 py-2.5 flex justify-around items-center shadow-lg">
          <button onClick={() => setTab("feed")} className={`flex flex-col items-center transition ${tab === "feed" ? "text-cyan-600" : "text-slate-400"}`}>
            <MapPin size={17} />
            <span className="text-[9px] font-semibold mt-0.5">Radar</span>
          </button>
          <button onClick={() => setTab("orders")} className={`flex flex-col items-center transition ${tab === "orders" ? "text-cyan-600" : "text-slate-400"}`}>
            <ShoppingBag size={17} />
            <span className="text-[9px] font-semibold mt-0.5">Pedidos</span>
          </button>
          <button onClick={() => setTab("profile")} className={`flex flex-col items-center transition ${tab === "profile" ? "text-cyan-600" : "text-slate-400"}`}>
            <User size={17} />
            <span className="text-[9px] font-semibold mt-0.5">Perfil</span>
          </button>
        </nav>

        {/* Checkout modal */}
        {checkoutItem && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm flex items-end justify-center z-50">
            <div className="bg-white w-full rounded-t-3xl p-5 shadow-2xl">
              <div className="flex justify-between items-center mb-3.5">
                <h3 className="font-bold text-slate-800 text-[15px]">Reserva relâmpago</h3>
                <button onClick={() => { setCheckoutItem(null); setPixData(null); }} className="text-slate-400 p-1">
                  <X size={18} />
                </button>
              </div>
              <div className="bg-cyan-50 border border-cyan-100 rounded-xl p-3 mb-3.5 text-[12px] text-slate-700 space-y-1">
                <p className="font-bold text-slate-900">{checkoutItem.name}</p>
                <p className="flex justify-between">
                  <span>Valor total:</span>
                  <strong className="text-cyan-700 font-bold text-[13px]">R$ {checkoutItem.price.toFixed(2)}</strong>
                </p>
                <p className="flex justify-between">
                  <span>Retirada:</span>
                  <span className="text-emerald-600 font-semibold">Até 20 min no balcão</span>
                </p>
              </div>
              <div className="text-center space-y-2.5">
                <p className="text-[11px] text-slate-500">Pague via PIX para garantir sua unidade:</p>
                <div className="w-32 h-32 bg-slate-100 border-2 border-dashed border-slate-300 rounded-xl mx-auto flex items-center justify-center text-slate-400 overflow-hidden">
                  {pixLoading ? (
                    <span className="text-[10px]">Gerando QR Code...</span>
                  ) : pixData?.qr_code_image ? (
                    <img src={pixData.qr_code_image} alt="QR Code PIX" className="w-full h-full object-contain" />
                  ) : pixData?.error ? (
                    <span className="text-[10px] px-2 text-center">Não foi possível gerar o PIX agora (verifique se a função foi publicada)</span>
                  ) : (
                    <QrCode size={40} />
                  )}
                </div>
                <button onClick={confirmOrder} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-[13px] shadow transition">
                  Confirmar pagamento PIX
                </button>
                <p className="text-[9px] text-slate-400 pt-1">
                  Modo de teste — nenhum valor real é cobrado.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Toast */}
        {toast && (
          <div className="absolute top-14 left-3.5 right-3.5 bg-emerald-600 text-white text-[11px] font-semibold py-2.5 px-3.5 rounded-xl shadow-lg flex items-center gap-2 z-50">
            <CheckCircle2 size={15} />
            <span>{toast}</span>
          </div>
        )}
      </div>
    </div>
  );
}
